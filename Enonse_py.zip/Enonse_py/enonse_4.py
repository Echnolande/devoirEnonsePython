nonb1 = int(input('Rantre yon premye nonb'))
nonb2 = int(input('Rantre yon lot nonb'))

reziltaMiltiplikasyon = nonb1 * nonb2
reziltaSoustraksyon = nonb1 - nonb2
reziltaAdisyon = nonb1 + nonb2
reziltaDivizyon = nonb1 / nonb2

print('Adisyon:----------->',reziltaAdisyon)
print('Soustraksyon:------------>',reziltaSoustraksyon)
print('Divizyon:-------------------->',reziltaDivizyon)
print('Miltiplikasyon:------------------>',reziltaMiltiplikasyon)