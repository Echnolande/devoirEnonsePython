a = 5
b = 5.8
c = "verifye"
d = False
print(type(a))
print(type(b))
print(type(c))
print(type(d))