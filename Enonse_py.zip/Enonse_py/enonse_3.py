non = "Echnolande Jacques"
laj = 23
print("Mw se "+non+", mw gen " +str(laj)+" lane")